library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;
--use ieee.numeric_std.all;
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity led_controler is
PORT(
    clk_100Meg: in std_logic;
    rst: in std_logic;
    btn1: in std_logic;
    btn2: in std_logic;
    led: out std_logic_vector (8 downto 0));
end led_controler;

architecture Behavioral of led_controler is
 CONSTANT MAX_WIDTH: natural:= 5; -- Set MAX_WIDTH := 5 for simulation only
                                   -- Set MAX_WIDTH := 26 for hardware implementation only
     signal ctick: std_logic :='0';
     signal aux_blink: std_logic :='0';
     signal shift_reg: std_logic_vector (8 downto 0) := "000000000";
    signal sh_led_a: std_logic_vector (8 downto 0):="000000000";
    signal sh_led_af: std_logic_vector (8 downto 0):="000000000";
    signal sh_led_c: std_logic_vector (8 downto 0):="000000000";

   

begin 
 -- process for ctick generation by "clock division"
 process(clk_100Meg)
    variable counter : std_logic_vector (MAX_WIDTH-1 downto 0) := (others =>'0');
    constant all_ones: std_logic_vector (MAX_WIDTH-1 downto 0) := (others =>'1');
    
begin
        if rising_edge(clk_100Meg) then
            counter := counter + 1;
        end if;
        if counter = all_ones then
            ctick <= '1';
        else
            ctick <= '0';
        end if;
end process;

process (clk_100Meg)
    begin
        if clk_100Meg'event and clk_100Meg='1' then --if rising_edge (clk_100Meg)

           if rst = '1' then
               shift_reg <= "000000000";
           elsif (ctick ='1') then
                if(shift_reg="000000000") then
                    shift_reg(0)<='1';
                else
                shift_reg <= shift_reg(7 downto 0) & shift_reg(8);
                end if;
           end if;
        end if;
end process;


process(shift_reg)--conrtolo do output dos leds
     begin
    --definir ciclo azul
    sh_led_a(0) <= shift_reg(0) or shift_reg(8);
    sh_led_a(1) <= shift_reg(1) or shift_reg(7);
    sh_led_a(2) <= shift_reg(2) or shift_reg(6);
    sh_led_a(3) <= shift_reg(3) or shift_reg(5);
    sh_led_a(4) <= shift_reg(4);
    sh_led_a(8) <= shift_reg(0) or shift_reg(8);
    sh_led_a(7) <= shift_reg(1) or shift_reg(7);
    sh_led_a(6) <= shift_reg(2) or shift_reg(6);
    sh_led_a(5) <= shift_reg(3) or shift_reg(5);
 
       
end process;

process(sh_led_a,btn1)--conrtolo do output dos leds
     begin
     if(btn1='0') then
    --definir ciclo azul
    sh_led_af<=sh_led_a;
    end if;     
end process;

process(sh_led_a) --led castanho
     begin
    sh_led_c <= not sh_led_a;  
end process;

process(sh_led_a, sh_led_c, btn1, btn2) --decisor dos leds
    begin
    if(btn1 /= '1') then
            if(btn2='0')then
                led <= sh_led_a;
            else
                led <= sh_led_c;
            end if;
        elsif(btn1='1' and btn2='1') then
            if(aux_blink='0') then
                led <= sh_led_a;
            else 
                led <= sh_led_c;           
            end if;
        else 
            led<=sh_led_af;
                 
        end if;   
end process;

process(clk_100Meg) --criação do aux blink
begin
 if rising_edge(clk_100Meg) then
 if rst='1' then
 aux_blink <='0';
 elsif (ctick ='1') then
 aux_blink <= not aux_blink ;
 end if;
 end if;
 end process;
 




--process (clk_100Meg)  --processo em que os registos fazem o shift da pontas para o meio
--variable rise: integer; --controlo de direção rise=1 dos extremos para o meio, rise=0 sentido oposto
--         begin ----- registo de 9 bits seguidos
--            if clk_100Meg'event and clk_100Meg='1' then
--                    if rst = '1' then
--                        shift_reg <= "000000000";
--                        rise:=1;
--                    elsif (ctick = '1') then
--            -- Se o registro estiver vazio, inicializa com '1' no bit 0
--            if (shift_reg = "000000000") then
--                shift_reg(0) <= '1';
--                shift_reg(8) <='1';
--                rise:=1;
--                elsif(rise=1) then
--                    shift_reg(8 downto 4)<= '0' & shift_reg(8 downto 5);
--                    shift_reg(3 downto 0)<=shift_reg(2 downto 0) & '0';
--                    if(shift_reg(4)='1')then
--                        rise:=0;     
--                    end if;  
--                end if;
--            if(rise=0) then
--            shift_reg(8 downto 4)<= shift_reg(7 downto 4) & '0';
--            shift_reg(4 downto 0)<='0'&shift_reg(4 downto 1);
--            end if; 
--        end if;
--      end if;
--end process;

--process(clk_100Meg)
--    begin
--    if clk_100Meg'event and clk_100Meg='1' then
--        if(btn1 /= '1') then
--            if(btn2='0')then
--                led <= shift_reg;
--            else
--                led <= not shift_reg;
--            end if;
--        elsif(btn1='1' and btn2='1') then
--            if(aux_blink='0') then
--                led <= shift_reg;
--            else 
--                led <= not shift_reg;
              
--            end if;
--        end if;
--    end if;
--end process;     
            
 end Behavioral;           
    
