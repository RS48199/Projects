SEADP2425SI G06
************************************************
Estes ficheiros são copias do projeto original,
para fins de objeto do Relatório.
Projeto original segue em anexo também.
************************************************
