library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Testbench entity
entity tb_led_controler is
end tb_led_controler;

-- Testbench architecture
architecture Behavioral of tb_led_controler is

    -- Component declaration for the Unit Under Test (UUT)
    component led_controler
    PORT(
        clk_100Meg: in std_logic;
        rst: in std_logic;
        btn1: in std_logic;
        btn2: in std_logic;
        led: out std_logic_vector(8 downto 0)
    );
    end component;

    -- Signals for the testbench
    signal clk_100Meg: std_logic := '0';
    signal rst: std_logic := '0';
    signal btn1: std_logic := '1';
    signal btn2: std_logic;
    signal led: std_logic_vector(8 downto 0);
   -- signal aux_blink: std_logic :='0';

    -- Clock period definition
    constant clk_period: time := 10 ns; -- 100 MHz clock

begin

    -- Instantiate the Unit Under Test (UUT)
    uut: led_controler
    PORT MAP (
        clk_100Meg => clk_100Meg,
        rst => rst,
        btn1 => btn1,
        led => led,
        btn2 => btn2
        --aux_blink => aux_blink;
    );

    -- Clock process
    clk_process: process
    begin
        clk_100Meg <= '0';
        wait for clk_period / 2;
        clk_100Meg <= '1';
        wait for clk_period / 2;
    end process;

    -- Test process
    stim_proc: process
    begin
    
    wait for 100 ns;
        btn1<='0'; 
        rst <= '0';
        btn2<= '0';
        
        -- Apply reset
        rst <= '1';
       
        wait for 20 ns; -- Wait for 20 ns
      
         rst <= '0';
     
        wait for 150 ns;
        
        -- Release button (btn1 = '1')
        btn1 <= '1';
        wait for 500 ns;
         btn1 <= '0';
       
       
       wait for 150 ns;
        
        -- Release button
        btn1 <= '1';
        wait for 150 ns;
        
        btn1 <='0';
        
        -- Simulate btn2 
        btn2 <= '1';
        wait for 120 ns;
        btn2 <='0';
        
        wait for 120 ns;
        btn2 <= '1';
        btn1 <= '1';
        wait for 120 ns;
        btn2 <='0';
        btn2 <='1';
        
        
        
        
        -- Finish simulation
        wait;
    end process;

end Behavioral;
