#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>
#include "booklibdin.h"
#include "lnode.h"
#include "tnode.h"

//defines necessários
#define MAX_BUFFER_SIZE 512

//////////////////////////MINHAS FUNCS/////////////////////////////////////

void instance_tnode(TNode **node, DynCollection *coll, int *i) {
    char delim[] = " ,"; // Delimitadores para separar nomes
    char buffer[MAX_BUFFER_SIZE]; // Buffer temporário para copiar os nomes dos autores
    int aux=0;

    for (int i = 0; i < vecRefSize(coll->titleVec); i++) {
        Book *b = vecRefGet(coll->titleVec, i);
        strcpy(buffer,b->authors);
        // Dividir os nomes dos autores usando strtok
        char *name = strtok(buffer, delim);
        while (name != NULL) {
			aux++;
            // Adicionar cada nome como um TNode na árvore
            bstAdd(node, name, b);
            name = strtok(NULL, delim); // Próximo nome
        }
    }
    *i=aux;
}




int main(int argc, char *argv[]) {
    char choice;
    char arg[MAX_BUFFER_SIZE];
    char input_line[MAX_BUFFER_SIZE];
	int i=0; //dbg
	int x=0; //""
	int y=0; //""
    // Criar a coleção dinâmica de livros
    DynCollection *coll = dynCollCreate();
    int nbooks = dynCollFill(coll, argv[1]);
    if (nbooks == coll->titleVec->size) 
        printf("Inseridos %d livros\n", nbooks);
    // Criar a árvore binária para autores
    TNode *node = NULL;
    instance_tnode(&node, coll,&i);
    x=bst_count(node);
    bstBalance(&node);
    y=bst_count(node);
    printf("Criada BST com i=%d, x=%d, y=%d nós\n", i,x,y);
	
    // Menu principal
    while (1) {
        print_dyncoll_menu();
        if (gets(input_line) == -1) { // gets vai dar warning por ser "perigoso"
            puts("Erro ao ler a entrada.");
        } else {
            sscanf(input_line, " %c %s", &choice, arg);
        }

        if (choice=='l') {
            print_dyncoll_ref_title(coll);
        }
        if (choice=='i') {
            if (arg==NULL) {
                puts("Erro: Má leitura do ISBN.");
            } else {
                Book *match = vecRefSearchIsbn(coll->isbnVec, arg);
                if (match==NULL) {
                    puts("Sem livros com essa referência.");
                } else {
                    print_match_isbn(match);
                }
            }
        }
        if(choice=='a') {
            if (arg==NULL) {
                puts("Erro: Má leitura do autor.");
            } else {
                LNode *match=bstSearch(node, arg);
                if (match==NULL) {
                    printf("Sem referências de livros com autores \"%s\"\n", arg);
                } else {
					puts("encontrados os seguintes livros:"); 
                    lRefPrint(match);
                }
            }
        }
        if(choice=='q'){
			bstFree(node);
			puts("Arvore e listas eliminadas com sucesso");
			dynCollFree(coll);
			puts("Referencias eliminadas com sucesso");
			break;
		}
    }

    return 0;
}

