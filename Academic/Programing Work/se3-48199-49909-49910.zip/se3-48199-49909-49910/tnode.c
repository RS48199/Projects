#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>
#include "booklibdin.h"
#include "lnode.h"
#include "tnode.h"

char *splitField(char *str);
void separatorUnify(char str[]);
int strcmp_ic( const char *str1, const char *str2 );
int processFile(const char *filename, int (*action)(const char *line, void *context), void *context);
int linePrintRaw(const char *line, void *context);
int lineFilterPrint(const char *line, void *context);

void bstAdd( TNode **rootPtr, char *namWord, Book *ref ){
	if(namWord==NULL || ref==NULL) return;
	if(*rootPtr==NULL){ //arvore vazia ou estamos no extremo de uma
		if((*rootPtr=malloc(sizeof(TNode)))==NULL) return;
		(*rootPtr)->word=strdup(namWord);
		(*rootPtr)->left=(*rootPtr)->right=NULL;
		(*rootPtr)->head=NULL;
		lRefAdd(&((*rootPtr)->head), ref); //já existe
		return; 
	}
	if((strcmp_ic(namWord,(*rootPtr)->word))==0){
		lRefAdd(&((*rootPtr)->head), ref);
		return;
	}
	if((strcmp_ic(namWord,(*rootPtr)->word))<0){
		bstAdd(&((*rootPtr)->left),namWord,ref);
	}
	if((strcmp_ic(namWord,(*rootPtr)->word))>0){
		bstAdd(&((*rootPtr)->right),namWord,ref);
	}
}

int bst_count(TNode *root) {
    if (root == NULL) {
        return 0; // Árvore vazia ou chegamos a um nó folha
    }

    // Contar o nó atual e somar os nós das subárvores esquerda e direita
    return 1 + bst_count(root->left) + bst_count(root->right);
}


TNode *treeToSortedList( TNode *r, TNode *link ){
	TNode * p;
	if( r == NULL ) return link;
	p = treeToSortedList( r->left, r );
	r->left = NULL;
	r->right = treeToSortedList( r->right, link );
	return p;
}


TNode *sortedListToBalancedTree(TNode **listRoot, int n) {
	if( n == 0 ) return NULL;
	TNode *leftChild = sortedListToBalancedTree(listRoot, n/2);
	TNode *parent = *listRoot;
	parent->left = leftChild;
	*listRoot = (*listRoot)->right;
	parent->right = sortedListToBalancedTree(listRoot, n-(n/2 + 1) );
	return parent;
} 
 

void bstBalance( TNode **rootPtr ){
	if(*rootPtr==NULL) return;
	*rootPtr=treeToSortedList(*rootPtr, NULL);
	int count=bst_count(*rootPtr);
	*rootPtr=sortedListToBalancedTree(rootPtr,count);
}

LNode* bstSearch(TNode *root, char *namWord){
    if (root==NULL || namWord==NULL) return NULL; 
    if (strcmp_ic(namWord, root->word)== 0) {
        return root->head; // Palavra encontrada
    } else if (strcmp_ic(namWord, root->word)<0) {
        return bstSearch(root->left, namWord); // Buscar na subárvore esquerda
    } else {
        return bstSearch(root->right, namWord); // Buscar na subárvore direita
    }
}

void bstFree(TNode *root) {
    if (root == NULL) {
        return;
    }

    // Libera as subárvores esquerda e direita
    bstFree(root->left);
    bstFree(root->right);

    // Libera a lista ligada associada ao nó
    lRefFree(root->head);

    // Libera o próprio nó
    free(root->word); // Libera a string duplicada (strdup)
    free(root);
}


//////////////////////////////////////////////////////////////////////////
