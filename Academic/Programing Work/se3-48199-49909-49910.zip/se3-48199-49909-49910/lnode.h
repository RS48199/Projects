#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>
#include "booklibdin.h"
#ifndef _L_NODE_H_
#define _L_NODE_H_

typedef struct lNode{
	struct lNode *next; // ligação na lista
	Book *ref; // referência de acesso a um descritor de livro
} LNode; 

int lRefAdd( LNode **headPtr, Book *ref ); 
void lRefPrint( LNode *head );
void lRefFree( LNode *head );
////////////////////////////////////////////////////////
void print_l_node(LNode *node);

#endif

