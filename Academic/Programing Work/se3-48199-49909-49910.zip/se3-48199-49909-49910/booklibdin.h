#ifndef _BOOKLIBDIN_H_
#define _BOOKLIBDIN_H_
#define MAX_ISBN 32
#define VEC_INCREMENT 6

typedef struct { // Descritor dos dados de um livro
 char *title; // string alojada dinamicamente
 char isbn[MAX_ISBN]; // string com dimensão fixa
 char *authors; // string alojada dinamicamente
 char *publisher; // string alojada dinamicamente
} Book;
typedef struct{ // Descritor de um vetor
 Book **refs; // array alojado dinamicamente
 int size; // quantidade de elementos preenchidos
 int space; // quantidade de elementos alojados
} VecBookRef;
typedef struct{ // Descritor de um vetor
 VecBookRef *titleVec; // vetor a ordenar por título
 VecBookRef *isbnVec; // vetor a ordenar por isbn
} DynCollection; 

Book *bookCreate( const char *line ); 
void bookFree( Book *b ); 
VecBookRef *vecRefCreate ( void );
void vecRefAdd( VecBookRef *vec, Book *ref );
int vecRefSize( VecBookRef *vec ); 
Book *vecRefGet( VecBookRef *vec, int index ); 
void vecRefSortTitle( VecBookRef *vec ); 
void vecRefSortIsbn( VecBookRef *vec ); 
Book *vecRefSearchIsbn( VecBookRef *vec, char *isbn ); 
void vecRefFree( VecBookRef *vec, int freeBooks ); 
DynCollection *dynCollCreate(void);
int dynCollAddBook(const char* line, void * context);
int dynCollFill(DynCollection *coll, const char* filename);
void dynCollFree(DynCollection *coll);

//********************************************************************************************************
//********************************************Minhas Funcs************************************************
//********************************************************************************************************

void print_dyncoll_menu();
void print_book(Book* b);
void print_ref_vec(VecBookRef* vec);
void print_dyncoll_ref_title(DynCollection* coll);
void print_match_isbn(Book* b);
#endif

