#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>
#include "booklibdin.h"
#include "lnode.h"


char *splitField(char *str);
void separatorUnify(char str[]);
int strcmp_ic( const char *str1, const char *str2 );
int processFile(const char *filename, int (*action)(const char *line, void *context), void *context);
int linePrintRaw(const char *line, void *context);
int lineFilterPrint(const char *line, void *context);

//feito iterativamente
int lRefAdd(LNode **headPtr, Book *ref) {
    if (ref == NULL) {
        return 0; // Erro
    }
    LNode *newNode = (LNode*)malloc(sizeof(LNode));
    if (newNode == NULL) {
        return 0; // Erro
    }
    newNode->ref = ref;
    newNode->next = NULL;
    if (*headPtr == NULL) {
        *headPtr = newNode;
    } else {
        newNode->next = *headPtr;
        *headPtr = newNode;
    }
    return 0; // Sucesso
}


//parte-se do pressuposto que todos os livros foram bem inicilaizados e ligados e não há apontadores para referencias NULAS
void lRefPrint( LNode *head ){
	while(head!=NULL){
		if(head->ref!=NULL) print_book(head->ref);
		head=head->next;
	}
}

void lRefFree(LNode *head) {
    LNode *current = head;
    while (current != NULL) {
        LNode *temp = current;
        current = current->next;
        free(temp); // Libera o nó atual
    }
}

//////////////////////////////////////////////////////////////////////////


