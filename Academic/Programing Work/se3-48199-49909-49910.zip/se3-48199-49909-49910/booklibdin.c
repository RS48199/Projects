#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "booklibdin.h"
//macros menu
char menu_choices[]={'l','a','i','q'};
char *menu_str[]={"Apresenta a lista de todos os livros, com ordem alfabeticamente crescente por título;",
				  "Escreva o nome do autor, e serao apresntados os livros desse autor;",
				  "Apresenta os dados relativos ao livro com o ISBN indicado;",
				  "Termina."};


//funcs da se-01 e se-02
char *splitField(char *str);
void separatorUnify(char str[]);
int strcmp_ic( const char *str1, const char *str2 );
int processFile(const char *filename, int (*action)(const char *line, void *context), void *context);
int linePrintRaw(const char *line, void *context);
int lineFilterPrint(const char *line, void *context);

Book *bookCreate( const char *line ){
	Book* aux=(Book*)malloc(sizeof(Book));
	if(aux==NULL || line==NULL) return NULL;
	int count=0;
	
	char* tmp=strdup(line);
	char *p1 = tmp, *p2;
	do{
		count++;
		p2 = splitField(p1);
		separatorUnify(p1);
		if(count==1){ 
			aux->title=strdup(p1);	
		}
		if(count==2){
			strcpy(aux->isbn,p1);
		}
		if(count==4){
			aux->authors=strdup(p1);
		}
		if(count==5){
			aux->publisher=strdup(p1);
			break; //n ha necessidade de continuar o while
		}		
	}while ((p1=p2)!=NULL);
	free(tmp);
	free(p2);
	free(p1);
	return aux; 
	
}

void bookFree( Book *b ){
	if(b==NULL) return;
	free(b->title);
	free(b->authors);
	free(b->publisher);
	free(b);
}

//adaptado codigo priority queue das aulas
VecBookRef *vecRefCreate(){
	VecBookRef* vbr=(VecBookRef*)malloc(sizeof(VecBookRef));
	if(vbr==NULL) return NULL;
	vbr->refs=NULL;
	vbr->size=vbr->space=0;
	return vbr;
} 

void vecRefAdd( VecBookRef *vec, Book *ref ){
	if(vec==NULL) return;
	if(vec->space==vec->size){
		Book **new_ref=realloc(vec->refs,sizeof(Book*)*(vec->space+VEC_INCREMENT));
		if(new_ref==NULL) return;
		vec->space+=VEC_INCREMENT;
		vec->refs=new_ref;
	}
	vec->refs[vec->size++]=ref;
}

int vecRefSize( VecBookRef *vec){
	return vec->size;
}

Book *vecRefGet( VecBookRef *vec, int index ){
	if(vec==NULL || index<0 || index>(vec->size-1)) return NULL;
	return vec->refs[index];
}

//auxiliar de vecRefSortIsbn retirado da se2 e adaptado
static int cmp_vec_ref_ISBN(const void* ptr1, const void* ptr2){
	Book *p1 = *((Book**)ptr1);
	Book *p2 = *((Book**)ptr2);
	return strcmp_ic(p1->isbn, p2->isbn);
}
//organiza as refs pela regra do comparador acima
void vecRefSortIsbn(VecBookRef *vec) {
    if (vec == NULL) return;
    qsort(vec->refs, vec->size, sizeof(Book*), cmp_vec_ref_ISBN);
}

Book *vecRefSearchIsbn( VecBookRef *vec, char *isbn ){
	if (vec == NULL) return NULL;
	Book temp;
	strcpy(temp.isbn, isbn);
	Book *temp_ptr = &temp;
	Book** match=(Book**)bsearch(&temp_ptr,vec->refs, vec->size, sizeof(Book*), cmp_vec_ref_ISBN);
	return *match;

}

//função auxiliar ao collSortTitle para passar como parm comparator do qsort
static int cmp_vec_ref_title(const void* ptr1, const void* ptr2){
    Book *p1 = *((Book **)ptr1);
    Book *p2 = *((Book **)ptr2);
    return strcmp_ic(p1->title, p2->title); 
}

void vecRefSortTitle( VecBookRef *vec ){
	if(vec==NULL||vec->size<0){return;}
	qsort(vec->refs,vec->size,sizeof(Book*),cmp_vec_ref_title);
}


void vecRefFree( VecBookRef *vec, int freeBooks ){
	if(vec==NULL)return;
	//verificar o estado de freebooks
	if(vec->refs!=NULL){
		if(freeBooks){
			for(int i=0;i<vec->size; i++){
				bookFree(vec->refs[i]);
			}
		}
		free(vec->refs);
		vec->size=vec->space=0;
		free(vec);
	}	
}

DynCollection *dynCollCreate(){
	DynCollection *coll=(DynCollection*)malloc(sizeof(DynCollection));
	if(coll==NULL) return NULL;
	coll->titleVec=vecRefCreate();
	if(coll->titleVec==NULL){free(coll); return NULL;}
	coll->isbnVec=vecRefCreate();
	if(coll->isbnVec==NULL){vecRefFree(coll->titleVec,0); free(coll); return NULL;}//no vec free é irrelevante por 0 ou 1 pois a estrutura ainda nao esta carregada
	return coll;
}

int dynCollAddBook(const char* line, void * context){
	DynCollection *coll=(DynCollection*) context;
	if(coll==NULL) return 0;
	Book* b=bookCreate(line);
	if(b==NULL) return 0;
	vecRefAdd(coll->titleVec, b);
	vecRefAdd(coll->isbnVec, b);
	return 1;
}

int dynCollFill(DynCollection *coll, const char* filename){
	int i=processFile(filename,dynCollAddBook,coll);
	vecRefSortTitle(coll->titleVec);
	vecRefSortIsbn(coll->isbnVec);
	return i;
}

void dynCollFree(DynCollection *coll){
	if(coll==NULL) return;
	//vecRefFree(coll->titleVec, 0);
	vecRefFree(coll->titleVec, 1);
	free(coll);
}


//********************************************************************************************************
//********************************************Minhas Funcs************************************************
//********************************************************************************************************

void print_dyncoll_menu(){
	printf("********************\n");
	printf("**Menu da colecao***\n");
	printf("Lista de opcoes:\n");
	for(int i=0; i<sizeof(menu_choices);i++){
	printf("%c: %s\n",menu_choices[i],menu_str[i]);
	}
	printf("A sua opcao:");
}

void print_book(Book* b){	
	printf("%s;%s;%s;%s\n", b->title, b->isbn, b->authors, b->publisher);
}

void print_ref_vec(VecBookRef* vec){
	for(int i=0; i<vecRefSize(vec);i++){
		print_book(vecRefGet(vec,i));
		}
}

void print_dyncoll_ref_title(DynCollection* coll){
	print_ref_vec(coll->titleVec);
	}
	
void print_match_isbn(Book* b){
	printf("Encontrado um livro com a referencia %s:\n",b->isbn);
	print_book(b);
}














