/* Data:21/10/24
 * Turma: LT31N
 * Grupo:09
 * Author: 48199
 * Editors: 49909/49910
*/

//includes
#include <stdio.h>
#include <limits.h>
#include <string.h>
#include <ctype.h>
//defines
#define MAX_STREAM 512

char *splitField(char *str);
void separatorUnify(char str[]);
int strcmp_ic( const char *str1, const char *str2 );


int processFile( const char *filename,int (*action)( const char *line, void *context ),void *context ){
	FILE *fp;
	char str[MAX_STREAM];
	int count=0;
	if((fp=fopen(filename,"r"))==NULL){return -1;}
	while(fgets(str,sizeof(str),fp)!=NULL){
		count+=action(str, context);
	}
	return count;
}

int linePrintRaw( const char *line, void *context ){
	if(line==NULL){return 0;}
	printf("%s",line);
	return 1;
} 
//nao é eficiente usar esta função para printar books ou collections

int lineFilterPrint( const char *line, void *context ){
	char temp[MAX_STREAM];
	if(line==NULL){return 0;}
	strcpy(temp, line); //nao podemos modificar line por ser passada como const char*
	char *p1 = temp, *p2;
	p2 = splitField(p1); //p2 nao será usado, retirado do filter.c da SE1 sem while pq queremos o primeir campo 
    separatorUnify(p1);
    if (p1 != NULL && !strcmp_ic((char*)context, p1)) {
		printf("%s\n", line);  // Imprimir a linha se coincidir
		return 1;
    }else{
		return 0;
		}
} 
