#include <stdio.h>
#include <limits.h>
#include <string.h>
#include <ctype.h>

//funções 
char *splitField(char *str) {
    int i = 0;
    if (str[i] == '\0') { 
        return NULL;
    }
    while (str[i] != '\0') {
        if (str[i] == ';') {
            str[i] = '\0';  
            return &str[i + 1]; //retorna a posição de memoria i+1 de modo a continuar a iteração 
        }
        i++;
    }
    return NULL;
}

void separatorUnify(char str[]) {
    if (str == NULL) return; // Evitar processar string nula

    int i = 0, j = 0;
    int s = 0;  // Flag para controlar espaço
    while (str[i] != '\0' && (isspace(str[i])|| iscntrl(str[i]))) { //ignora todos os espaços e caracteres de controlo ao inicio menos o \0
        i++;
    }

    while (str[i] != '\0') {
        if (isalnum(str[i]) || ispunct(str[i])) {  // Copia caracteres alfanuméricos e pontuação
            str[j++] = str[i++];
            s = 0;    // Reseta a flag de espaço
        } else {  // Encontrar um separador
            if (!s) { // Adicionar um espaço apenas se não houver um antes
                str[j++] = ' ';
                s = 1;
            }
            i++;
        }
    }
    //como se coloca o 1 espaço e incrementa-se j antes de encontrar a proxima palavra pode acontecer que 
    //não haja proxima palavra, logo terminar num só espaço, para isso usa-se este if para quando isso acontece
    //j decrementar 1
    if (j > 0 && isspace(str[j-1])) {
        j--;
    }
    str[j] = '\0'; // Termina a string
}

int strcmp_ic(const char *str1, const char *str2) {
  const unsigned char *p1 = (const unsigned char *) str1;
  const unsigned char *p2 = (const unsigned char *) str2;
  int result;
  if (p1 == p2)
    return 0;
  while ((result = tolower(*p1) - tolower(*p2++)) == 0)
    if (*p1++ == '\0')
      break;
  return result;
}


