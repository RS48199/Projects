#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>
#include "booklibdin.h"
#include "lnode.h"
#ifndef _T_NODE_H_
#define _T_NODE_H_

typedef struct tNode{
	struct tNode *left, *right;
	char *word;
	LNode *head;
} TNode; 

void bstAdd( TNode **rootPtr, char *namWord, Book *ref ); 
void bstBalance( TNode **rootPtr );
LNode* bstSearch(TNode *root, char *namWord);  
void bstFree(TNode *root);
int bst_count(TNode *root);
void print_t_node(TNode* root);
#endif


